import Chess.Game;
import ir.sharif.math.bp02_1.hex_chess.graphics.Application;

public class Main {
    public static void main(String[] args) {
        Application application = new Application();
        Game game = new Game(application);
    }
}