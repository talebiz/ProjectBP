package ir.sharif.math.bp02_1.hex_chess.graphics.listeners;

import java.io.File;

public class DummyEventListener implements EventListener {
    @Override
    public void onClick(int row, char col) {

    }

    @Override
    public void onLoad(File file) {

    }

    @Override
    public void onSave(File file) {

    }

    @Override
    public void onNewGame() {

    }
}
