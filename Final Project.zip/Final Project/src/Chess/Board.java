package Chess;

import Chess.Pieces.*;

import java.util.ArrayList;

public class Board {
    Piece[][] board;
    ArrayList<Piece> removedPieces;
    final char[][] graphicBoardChar;
    final int[][] graphicBoardInt;

    public Board() {
        board = new Piece[13][13];
        removedPieces = new ArrayList<>();
        graphicBoardChar = new char[13][13];
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 13; j++) {
                graphicBoardChar[i][j] = 'j';
            }
        }
        graphicBoardInt = new int[13][13];

//        board[1][1] = new Rook(1, 1, Color.WHITE, WHITE_ROCK);
//        board[2][6] = new Rook(2, 6, Color.BLACK, BLACK_ROCK);
//        board[5][5] = new Queen(5, 5, Color.BLACK, BLACK_QUEEN);
//        board[5][9] = new King(5, 9, Color.BLACK, BLACK_KING);
//        board[6][1] = new King(6, 1, Color.WHITE, WHITE_KING);
//        board[3][4] = new Knight(3, 4, Color.WHITE, WHITE_KNIGHT);
//        board[9][10] = new Bishop(9, 10, Color.WHITE, WHITE_BISHOP);
//        board[10][11] = new Pawn(10, 11, Color.BLACK, BLACK_PAWN);
//        board[6][10] = new Pawn(6, 10, Color.WHITE, WHITE_PAWN);

//        board[6][9] = new Rook(6, 9, Color.WHITE, WHITE_ROCK);
//        board[6][10] = new Pawn(6, 10, Color.WHITE, WHITE_PAWN);
//        board[6][11] = new King(6, 11, Color.BLACK, BLACK_KING);


//        board[2][1] = new Pawn(2, 1, Color.WHITE, WHITE_PAWN);
//        board[3][2] = new Pawn(3, 2, Color.WHITE, WHITE_PAWN);
//        board[4][3] = new Pawn(4, 3, Color.WHITE, WHITE_PAWN);
//        board[5][4] = new Pawn(5, 4, Color.WHITE, WHITE_PAWN);
//        board[6][5] = new Pawn(6, 5, Color.WHITE, WHITE_PAWN);
//        board[7][5] = new Pawn(7, 5, Color.WHITE, WHITE_PAWN);
//        board[8][5] = new Pawn(8, 5, Color.WHITE, WHITE_PAWN);
//        board[9][5] = new Pawn(9, 5, Color.WHITE, WHITE_PAWN);
//        board[10][5] = new Pawn(10, 5, Color.WHITE, WHITE_PAWN);
//        board[6][1] = new Bishop(6, 1, Color.WHITE, WHITE_BISHOP);
//        board[6][2] = new Bishop(6, 2, Color.WHITE, WHITE_BISHOP);
//        board[6][3] = new Bishop(6, 3, Color.WHITE, WHITE_BISHOP);
//        board[3][1] = new Rook(3, 1, Color.WHITE, WHITE_ROCK);
//        board[9][4] = new Rook(9, 4, Color.WHITE, WHITE_ROCK);
//        board[4][1] = new Knight(4, 1, Color.WHITE, WHITE_KNIGHT);
//        board[8][3] = new Knight(8, 3, Color.WHITE, WHITE_KNIGHT);
//        board[5][1] = new Queen(5, 1, Color.WHITE, WHITE_QUEEN);
//        board[7][2] = new King(7, 2, Color.WHITE, WHITE_KING);
//
//
//        board[2][7] = new Pawn(2, 7, Color.BLACK, BLACK_PAWN);
//        board[3][7] = new Pawn(3, 7, Color.BLACK, BLACK_PAWN);
//        board[4][7] = new Pawn(4, 7, Color.BLACK, BLACK_PAWN);
//        board[5][7] = new Pawn(5, 7, Color.BLACK, BLACK_PAWN);
//        board[6][7] = new Pawn(6, 7, Color.BLACK, BLACK_PAWN);
//        board[7][8] = new Pawn(7, 8, Color.BLACK, BLACK_PAWN);
//        board[8][9] = new Pawn(8, 9, Color.BLACK, BLACK_PAWN);
//        board[9][10] = new Pawn(9, 10, Color.BLACK, BLACK_PAWN);
//        board[10][11] = new Pawn(10, 11, Color.BLACK, BLACK_PAWN);
//        board[6][9] = new Bishop(6, 9, Color.BLACK, BLACK_BISHOP);
//        board[6][10] = new Bishop(6, 10, Color.BLACK, BLACK_BISHOP);
//        board[6][11] = new Bishop(6, 11, Color.BLACK, BLACK_BISHOP);
//        board[3][8] = new Rook(3, 8, Color.BLACK, BLACK_ROCK);
//        board[9][11] = new Rook(9, 11, Color.BLACK, BLACK_ROCK);
//        board[4][9] = new Knight(4, 9, Color.BLACK, BLACK_KNIGHT);
//        board[8][11] = new Knight(8, 11, Color.BLACK, BLACK_KNIGHT);
//        board[5][10] = new Queen(5, 10, Color.BLACK, BLACK_QUEEN);
//        board[7][11] = new King(7, 11, Color.BLACK, BLACK_KING);


        putGraphicBoardIntAndChar();
    }

    public void putGraphicBoardIntAndChar() {
        graphicBoardChar[1][1] = 'a';
        graphicBoardChar[2][1] = 'b';
        graphicBoardChar[3][1] = 'c';
        graphicBoardChar[4][1] = 'd';
        graphicBoardChar[5][1] = 'e';
        graphicBoardChar[6][1] = 'f';

        graphicBoardChar[1][2] = 'a';
        graphicBoardChar[2][2] = 'b';
        graphicBoardChar[3][2] = 'c';
        graphicBoardChar[4][2] = 'd';
        graphicBoardChar[5][2] = 'e';
        graphicBoardChar[6][2] = 'f';
        graphicBoardChar[7][2] = 'g';

        graphicBoardChar[1][3] = 'a';
        graphicBoardChar[2][3] = 'b';
        graphicBoardChar[3][3] = 'c';
        graphicBoardChar[4][3] = 'd';
        graphicBoardChar[5][3] = 'e';
        graphicBoardChar[6][3] = 'f';
        graphicBoardChar[7][3] = 'g';
        graphicBoardChar[8][3] = 'h';

        graphicBoardChar[1][4] = 'a';
        graphicBoardChar[2][4] = 'b';
        graphicBoardChar[3][4] = 'c';
        graphicBoardChar[4][4] = 'd';
        graphicBoardChar[5][4] = 'e';
        graphicBoardChar[6][4] = 'f';
        graphicBoardChar[7][4] = 'g';
        graphicBoardChar[8][4] = 'h';
        graphicBoardChar[9][4] = 'i';

        graphicBoardChar[1][5] = 'a';
        graphicBoardChar[2][5] = 'b';
        graphicBoardChar[3][5] = 'c';
        graphicBoardChar[4][5] = 'd';
        graphicBoardChar[5][5] = 'e';
        graphicBoardChar[6][5] = 'f';
        graphicBoardChar[7][5] = 'g';
        graphicBoardChar[8][5] = 'h';
        graphicBoardChar[9][5] = 'i';
        graphicBoardChar[10][5] = 'k';

        graphicBoardChar[1][6] = 'a';
        graphicBoardChar[2][6] = 'b';
        graphicBoardChar[3][6] = 'c';
        graphicBoardChar[4][6] = 'd';
        graphicBoardChar[5][6] = 'e';
        graphicBoardChar[6][6] = 'f';
        graphicBoardChar[7][6] = 'g';
        graphicBoardChar[8][6] = 'h';
        graphicBoardChar[9][6] = 'i';
        graphicBoardChar[10][6] = 'k';
        graphicBoardChar[11][6] = 'l';

        graphicBoardChar[2][7] = 'b';
        graphicBoardChar[3][7] = 'c';
        graphicBoardChar[4][7] = 'd';
        graphicBoardChar[5][7] = 'e';
        graphicBoardChar[6][7] = 'f';
        graphicBoardChar[7][7] = 'g';
        graphicBoardChar[8][7] = 'h';
        graphicBoardChar[9][7] = 'i';
        graphicBoardChar[10][7] = 'k';
        graphicBoardChar[11][7] = 'l';

        graphicBoardChar[3][8] = 'c';
        graphicBoardChar[4][8] = 'd';
        graphicBoardChar[5][8] = 'e';
        graphicBoardChar[6][8] = 'f';
        graphicBoardChar[7][8] = 'g';
        graphicBoardChar[8][8] = 'h';
        graphicBoardChar[9][8] = 'i';
        graphicBoardChar[10][8] = 'k';
        graphicBoardChar[11][8] = 'l';

        graphicBoardChar[4][9] = 'd';
        graphicBoardChar[5][9] = 'e';
        graphicBoardChar[6][9] = 'f';
        graphicBoardChar[7][9] = 'g';
        graphicBoardChar[8][9] = 'h';
        graphicBoardChar[9][9] = 'i';
        graphicBoardChar[10][9] = 'k';
        graphicBoardChar[11][9] = 'l';

        graphicBoardChar[5][10] = 'e';
        graphicBoardChar[6][10] = 'f';
        graphicBoardChar[7][10] = 'g';
        graphicBoardChar[8][10] = 'h';
        graphicBoardChar[9][10] = 'i';
        graphicBoardChar[10][10] = 'k';
        graphicBoardChar[11][10] = 'l';

        graphicBoardChar[6][11] = 'f';
        graphicBoardChar[7][11] = 'g';
        graphicBoardChar[8][11] = 'h';
        graphicBoardChar[9][11] = 'i';
        graphicBoardChar[10][11] = 'k';
        graphicBoardChar[11][11] = 'l';


        graphicBoardInt[1][1] = 1;
        graphicBoardInt[2][1] = 1;
        graphicBoardInt[3][1] = 1;
        graphicBoardInt[4][1] = 1;
        graphicBoardInt[5][1] = 1;
        graphicBoardInt[6][1] = 1;

        graphicBoardInt[1][2] = 2;
        graphicBoardInt[2][2] = 2;
        graphicBoardInt[3][2] = 2;
        graphicBoardInt[4][2] = 2;
        graphicBoardInt[5][2] = 2;
        graphicBoardInt[6][2] = 2;
        graphicBoardInt[7][2] = 1;

        graphicBoardInt[1][3] = 3;
        graphicBoardInt[2][3] = 3;
        graphicBoardInt[3][3] = 3;
        graphicBoardInt[4][3] = 3;
        graphicBoardInt[5][3] = 3;
        graphicBoardInt[6][3] = 3;
        graphicBoardInt[7][3] = 2;
        graphicBoardInt[8][3] = 1;

        graphicBoardInt[1][4] = 4;
        graphicBoardInt[2][4] = 4;
        graphicBoardInt[3][4] = 4;
        graphicBoardInt[4][4] = 4;
        graphicBoardInt[5][4] = 4;
        graphicBoardInt[6][4] = 4;
        graphicBoardInt[7][4] = 3;
        graphicBoardInt[8][4] = 2;
        graphicBoardInt[9][4] = 1;

        graphicBoardInt[1][5] = 5;
        graphicBoardInt[2][5] = 5;
        graphicBoardInt[3][5] = 5;
        graphicBoardInt[4][5] = 5;
        graphicBoardInt[5][5] = 5;
        graphicBoardInt[6][5] = 5;
        graphicBoardInt[7][5] = 4;
        graphicBoardInt[8][5] = 3;
        graphicBoardInt[9][5] = 2;
        graphicBoardInt[10][5] = 1;

        graphicBoardInt[1][6] = 6;
        graphicBoardInt[2][6] = 6;
        graphicBoardInt[3][6] = 6;
        graphicBoardInt[4][6] = 6;
        graphicBoardInt[5][6] = 6;
        graphicBoardInt[6][6] = 6;
        graphicBoardInt[7][6] = 5;
        graphicBoardInt[8][6] = 4;
        graphicBoardInt[9][6] = 3;
        graphicBoardInt[10][6] = 2;
        graphicBoardInt[11][6] = 1;

        graphicBoardInt[2][7] = 7;
        graphicBoardInt[3][7] = 7;
        graphicBoardInt[4][7] = 7;
        graphicBoardInt[5][7] = 7;
        graphicBoardInt[6][7] = 7;
        graphicBoardInt[7][7] = 6;
        graphicBoardInt[8][7] = 5;
        graphicBoardInt[9][7] = 4;
        graphicBoardInt[10][7] = 3;
        graphicBoardInt[11][7] = 2;

        graphicBoardInt[3][8] = 8;
        graphicBoardInt[4][8] = 8;
        graphicBoardInt[5][8] = 8;
        graphicBoardInt[6][8] = 8;
        graphicBoardInt[7][8] = 7;
        graphicBoardInt[8][8] = 6;
        graphicBoardInt[9][8] = 5;
        graphicBoardInt[10][8] = 4;
        graphicBoardInt[11][8] = 3;

        graphicBoardInt[4][9] = 9;
        graphicBoardInt[5][9] = 9;
        graphicBoardInt[6][9] = 9;
        graphicBoardInt[7][9] = 8;
        graphicBoardInt[8][9] = 7;
        graphicBoardInt[9][9] = 6;
        graphicBoardInt[10][9] = 5;
        graphicBoardInt[11][9] = 4;

        graphicBoardInt[5][10] = 10;
        graphicBoardInt[6][10] = 10;
        graphicBoardInt[7][10] = 9;
        graphicBoardInt[8][10] = 8;
        graphicBoardInt[9][10] = 7;
        graphicBoardInt[10][10] = 6;
        graphicBoardInt[11][10] = 5;

        graphicBoardInt[6][11] = 11;
        graphicBoardInt[7][11] = 10;
        graphicBoardInt[8][11] = 9;
        graphicBoardInt[9][11] = 8;
        graphicBoardInt[10][11] = 7;
        graphicBoardInt[11][11] = 6;

    }
}