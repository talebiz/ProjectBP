package Chess;

import Chess.Pieces.*;
import ir.sharif.math.bp02_1.hex_chess.graphics.Application;
import ir.sharif.math.bp02_1.hex_chess.graphics.models.StringColor;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import static ir.sharif.math.bp02_1.hex_chess.util.PieceName.*;

public class Game {
    public Application application;
    public Event event;
    Board chessBoard;
    Board boardForCheck;
    boolean isBlackPlayerToMove;
    File file;
    File removed;
    PrintWriter printWriter;
    PrintWriter printWriter2;
    Scanner sc;
    Scanner sc2;

    public Game(Application application) {
        this.application = application;
        event = new Event(this);
        chessBoard = new Board();
        application.registerEventListener(event);
        putGraphic();

        file = new File("C:\\Users\\taleb\\IdeaProjects\\Final Project\\Board.txt");
        removed = new File("C:\\Users\\taleb\\IdeaProjects\\Final Project\\RemovedPieces.txt");
        try {
            sc = new Scanner(file);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        String turn = sc.nextLine();
        if (turn.equals("W")) {
            isBlackPlayerToMove = false;
            application.setMessage("White's Turn");
        } else if (turn.equals("B")) {
            isBlackPlayerToMove = true;
            application.setMessage("Black's Turn");
        }
        while (sc.hasNextLine()) {
            int x;
            x = sc.nextInt();
            int y = sc.nextInt();
            String color = sc.next();
            String name = sc.next();
            String garbage = sc.nextLine();
            if (color.equals("W")) {
                if (name.equals("\u2656")) {
                    chessBoard.board[x][y] = new Rook(x, y, Color.WHITE, name);
                } else if (name.equals("\u2658")) {
                    chessBoard.board[x][y] = new Knight(x, y, Color.WHITE, name);
                } else if (name.equals("\u2657")) {
                    chessBoard.board[x][y] = new Bishop(x, y, Color.WHITE, name);
                } else if (name.equals("\u2655")) {
                    chessBoard.board[x][y] = new Queen(x, y, Color.WHITE, name);
                } else if (name.equals("\u2654")) {
                    chessBoard.board[x][y] = new King(x, y, Color.WHITE, name);
                } else if (name.equals("\u2659")) {
                    chessBoard.board[x][y] = new Pawn(x, y, Color.WHITE, name);
                }
            } else if (color.equals("B")) {
                if (name.equals("\u265C")) {
                    chessBoard.board[x][y] = new Rook(x, y, Color.BLACK, name);
                } else if (name.equals("\u265E")) {
                    chessBoard.board[x][y] = new Knight(x, y, Color.BLACK, name);
                } else if (name.equals("\u265D")) {
                    chessBoard.board[x][y] = new Bishop(x, y, Color.BLACK, name);
                } else if (name.equals("\u265B")) {
                    chessBoard.board[x][y] = new Queen(x, y, Color.BLACK, name);
                } else if (name.equals("\u265A")) {
                    chessBoard.board[x][y] = new King(x, y, Color.BLACK, name);
                } else if (name.equals("\u265F")) {
                    chessBoard.board[x][y] = new Pawn(x, y, Color.BLACK, name);
                }
            }
        }
        try {
            sc2 = new Scanner(removed);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        while (sc2.hasNextLine()) {
            int x = sc2.nextInt();
            int y = sc2.nextInt();
            String color = sc2.next();
            String name = sc2.next();
            String garbage = sc2.nextLine();
            if (color.equals("W")) {
                if (name.equals("\u2656")) {
                    chessBoard.removedPieces.add(new Rook(x, y, Color.WHITE, name));
                } else if (name.equals("\u2658")) {
                    chessBoard.removedPieces.add(new Knight(x, y, Color.WHITE, name));
                } else if (name.equals("\u2657")) {
                    chessBoard.removedPieces.add(new Bishop(x, y, Color.WHITE, name));
                } else if (name.equals("\u2655")) {
                    chessBoard.removedPieces.add(new Queen(x, y, Color.WHITE, name));
                } else if (name.equals("\u2654")) {
                    chessBoard.removedPieces.add(new King(x, y, Color.WHITE, name));
                } else if (name.equals("\u2659")) {
                    chessBoard.removedPieces.add(new Pawn(x, y, Color.WHITE, name));
                }
            } else if (color.equals("B")) {
                if (name.equals("\u265C")) {
                    chessBoard.removedPieces.add(new Rook(x, y, Color.BLACK, name));
                } else if (name.equals("\u265E")) {
                    chessBoard.removedPieces.add(new Knight(x, y, Color.BLACK, name));
                } else if (name.equals("\u265D")) {
                    chessBoard.removedPieces.add(new Bishop(x, y, Color.BLACK, name));
                } else if (name.equals("\u265B")) {
                    chessBoard.removedPieces.add(new Queen(x, y, Color.BLACK, name));
                } else if (name.equals("\u265A")) {
                    chessBoard.removedPieces.add(new King(x, y, Color.BLACK, name));
                } else if (name.equals("\u265F")) {
                    chessBoard.removedPieces.add(new Pawn(x, y, Color.BLACK, name));
                }
            }
        }
        draw();
    }

    public void changeBoard(int x, int y) {
        if (chessBoard.board[x][y] != null && !(chessBoard.board[x][y] instanceof Cell)
                && !(chessBoard.board[x][y].isCanSelectedPieceMoveHere())) {
            if ((isBlackPlayerToMove && chessBoard.board[x][y].getColor() == Color.BLACK)
                    || (!isBlackPlayerToMove && chessBoard.board[x][y].getColor() == Color.WHITE)) {
                for (int i = 1; i <= 11; i++) {
                    for (int j = 1; j <= 11; j++) {
                        if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof Cell) {
                            chessBoard.board[i][j] = null;
                        } else if (chessBoard.board[i][j] != null) {
                            chessBoard.board[i][j].setSelected(false);
                            chessBoard.board[i][j].setCanSelectedPieceMoveHere(false);
                        }
                    }
                }
                chessBoard.board = chessBoard.board[x][y].availableCells(chessBoard.board);
                for (int i = 1; i <= 11; i++) {
                    for (int j = 1; j <= 11; j++) {
                        boardForCheck = makeSameBoard(chessBoard);
                        if (boardForCheck.board[i][j] != null && boardForCheck.board[i][j].isCanSelectedPieceMoveHere()) {
                            moveFake(i, j);
                            King king = whichKingCheck(boardForCheck);
                            if (king != null) {
                                if ((isBlackPlayerToMove && king.getColor() == Color.BLACK)
                                        || (!isBlackPlayerToMove && king.getColor() == Color.WHITE)) {
                                    chessBoard.board[i][j].setCanSelectedPieceMoveHere(false);
                                }
                            }
                        }
                    }
                }

            }
        } else if (chessBoard.board[x][y] == null) {
            for (int i = 1; i <= 11; i++) {
                for (int j = 1; j <= 11; j++) {
                    if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof Cell) {
                        chessBoard.board[i][j] = null;
                    } else if (chessBoard.board[i][j] != null) {
                        chessBoard.board[i][j].setSelected(false);
                        chessBoard.board[i][j].setCanSelectedPieceMoveHere(false);
                    }

                }
            }
        } else if (chessBoard.board[x][y] != null && chessBoard.board[x][y].isCanSelectedPieceMoveHere()) {
            changeTurn();
            chessBoard = move(x, y, chessBoard);
            saveFile();
            if (isCheckmateOrStalemate()) {
                boolean isCheck = isCheck();
                if (isBlackPlayerToMove) {
                    if (isCheck) {
                        application.showMessagePopup("White won \n Checkmate");
                    } else {
                        application.showMessagePopup("White won \n Stalemate");
                    }
                }
                if (!isBlackPlayerToMove) {
                    if (isCheck) {
                        application.showMessagePopup("Black won \n Checkmate");
                    } else {
                        application.showMessagePopup("Black won \n Stalemate");
                    }
                }
                chessBoard = new Board();
                isBlackPlayerToMove = false;
                putDefaultBoard();
            }
        }
        draw();
    }

    public void draw() {
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (chessBoard.board[x][y] != null && chessBoard.board[x][y].isCanSelectedPieceMoveHere() && !(chessBoard.board[x][y] instanceof Cell)) {
                    application.setCellProperties(chessBoard.graphicBoardInt[x][y], chessBoard.graphicBoardChar[x][y], chessBoard.board[x][y].getName(), new Color(150, 100, 100), chessBoard.board[x][y].getColor());
                } else if (chessBoard.board[x][y] != null && chessBoard.board[x][y].isCanSelectedPieceMoveHere() && chessBoard.graphicBoardChar[x][y] != 'j') {
                    application.setCellProperties(chessBoard.graphicBoardInt[x][y], chessBoard.graphicBoardChar[x][y], null, new Color(150, 100, 100), null);
                } else if (chessBoard.board[x][y] != null && !(chessBoard.board[x][y].isCanSelectedPieceMoveHere()) && !(chessBoard.board[x][y] instanceof Cell)) {
                    application.setCellProperties(chessBoard.graphicBoardInt[x][y], chessBoard.graphicBoardChar[x][y], chessBoard.board[x][y].getName(), null, chessBoard.board[x][y].getColor());
                } else if (chessBoard.board[x][y] != null && chessBoard.board[x][y] instanceof Cell && chessBoard.graphicBoardChar[x][y] != 'j') {
                    chessBoard.board[x][y] = null;
                    application.setCellProperties(chessBoard.graphicBoardInt[x][y], chessBoard.graphicBoardChar[x][y], null, null, null);
                } else if (chessBoard.board[x][y] == null && chessBoard.graphicBoardChar[x][y] != 'j') {
                    application.setCellProperties(chessBoard.graphicBoardInt[x][y], chessBoard.graphicBoardChar[x][y], null, null, null);
                }
            }
        }
        StringColor[] removed = new StringColor[chessBoard.removedPieces.size()];
        for (int k = 0; k < removed.length; k++) {
            removed[k] = new StringColor(chessBoard.removedPieces.get(k).getName(), chessBoard.removedPieces.get(k).getColor());
        }
        application.setRemovedPieces(removed);
    }

    public Board move(int x, int y, Board chessBoard) {
        if (chessBoard.board[x][y] != null && !(chessBoard.board[x][y] instanceof Cell)) {
            chessBoard.removedPieces.add(chessBoard.board[x][y]);
        }
        loop:
        for (int i = 1; i <= 11; i++) {
            for (int j = 1; j <= 11; j++) {
                if (chessBoard.board[i][j] != null && chessBoard.board[i][j].isSelected()) {
                    chessBoard.board[i][j].setSelected(false);
                    if (chessBoard.board[i][j] instanceof Rook) {
                        chessBoard.board[x][y] = new Rook(x, y, chessBoard.board[i][j].getColor(), chessBoard.board[i][j].getName());
                    }
                    if (chessBoard.board[i][j] instanceof Bishop) {
                        chessBoard.board[x][y] = new Bishop(x, y, chessBoard.board[i][j].getColor(), chessBoard.board[i][j].getName());
                    }
                    if (chessBoard.board[i][j] instanceof Queen) {
                        chessBoard.board[x][y] = new Queen(x, y, chessBoard.board[i][j].getColor(), chessBoard.board[i][j].getName());
                    }
                    if (chessBoard.board[i][j] instanceof King) {
                        chessBoard.board[x][y] = new King(x, y, chessBoard.board[i][j].getColor(), chessBoard.board[i][j].getName());
                    }
                    if (chessBoard.board[i][j] instanceof Knight) {
                        chessBoard.board[x][y] = new Knight(x, y, chessBoard.board[i][j].getColor(), chessBoard.board[i][j].getName());
                    }
                    if (chessBoard.board[i][j] instanceof Pawn) {
                        if (chessBoard.board[i][j].getColor() == Color.BLACK && (y == 1 || y + 5 == x)) {
                            String newPiece = application.showPromotionPopup();
                            if (newPiece.equals("Knight")) {
                                chessBoard.board[x][y] = new Knight(x, y, chessBoard.board[i][j].getColor(), BLACK_KNIGHT);
                            } else if (newPiece.equals("Bishop")) {
                                chessBoard.board[x][y] = new Bishop(x, y, chessBoard.board[i][j].getColor(), BLACK_BISHOP);
                            } else if (newPiece.equals("Rook")) {
                                chessBoard.board[x][y] = new Rook(x, y, chessBoard.board[i][j].getColor(), BLACK_ROCK);
                            } else if (newPiece.equals("Queen")) {
                                chessBoard.board[x][y] = new Queen(x, y, chessBoard.board[i][j].getColor(), BLACK_QUEEN);
                            }
                        } else if (chessBoard.board[i][j].getColor() == Color.WHITE && (y == 11 || x + 5 == y)) {
                            String newPiece = application.showPromotionPopup();
                            if (newPiece.equals("Knight")) {
                                chessBoard.board[x][y] = new Knight(x, y, chessBoard.board[i][j].getColor(), WHITE_KNIGHT);
                            } else if (newPiece.equals("Bishop")) {
                                chessBoard.board[x][y] = new Bishop(x, y, chessBoard.board[i][j].getColor(), WHITE_BISHOP);
                            } else if (newPiece.equals("Rook")) {
                                chessBoard.board[x][y] = new Rook(x, y, chessBoard.board[i][j].getColor(), WHITE_ROCK);
                            } else if (newPiece.equals("Queen")) {
                                chessBoard.board[x][y] = new Queen(x, y, chessBoard.board[i][j].getColor(), WHITE_QUEEN);
                            }
                        } else {
                            chessBoard.board[x][y] = new Pawn(x, y, chessBoard.board[i][j].getColor(), chessBoard.board[i][j].getName());
                        }
                    }
                    chessBoard.board[i][j] = null;
                    break loop;
                }
            }
        }
        for (int i = 1; i <= 11; i++) {
            for (int j = 1; j <= 11; j++) {
                if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof Cell) {
                    chessBoard.board[i][j] = null;
                } else if (chessBoard.board[i][j] != null) {
                    chessBoard.board[i][j].setCanSelectedPieceMoveHere(false);
                }
            }
        }
        return chessBoard;
    }

    public boolean isCheck() {
        boolean out = false;
        loop:
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (chessBoard.board[x][y] != null && !(chessBoard.board[x][y] instanceof Cell)
                        && !(chessBoard.board[x][y] instanceof King)) {
                    for (int i = 1; i <= 11; i++) {
                        for (int j = 1; j <= 11; j++) {
                            if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof Cell) {
                                chessBoard.board[i][j] = null;
                            } else if (chessBoard.board[i][j] != null) {
                                chessBoard.board[i][j].setCanSelectedPieceMoveHere(false);
                                chessBoard.board[i][j].setSelected(false);
                            }
                        }
                    }
                    chessBoard.board = chessBoard.board[x][y].availableCells(chessBoard.board);
                    for (int i = 1; i <= 11; i++) {
                        for (int j = 1; j <= 11; j++) {
                            if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof King &&
                                    chessBoard.board[i][j].getColor() != chessBoard.board[x][y].getColor()
                                    && chessBoard.board[i][j].isCanSelectedPieceMoveHere()) {
                                out = true;
                                break loop;
                            }
                        }
                    }
                }
            }
        }
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (chessBoard.board[x][y] != null && chessBoard.board[x][y] instanceof Cell) {
                    chessBoard.board[x][y] = null;
                } else if (this.chessBoard.board[x][y] != null) {
                    this.chessBoard.board[x][y].setCanSelectedPieceMoveHere(false);
                    chessBoard.board[x][y].setSelected(false);
                }
            }
        }
        return out;
    }

    public King whichKingCheck(Board chessBoard) {
        King out = null;
        loop:
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (chessBoard.board[x][y] != null && !(chessBoard.board[x][y] instanceof Cell)) {
                    for (int i = 1; i <= 11; i++) {
                        for (int j = 1; j <= 11; j++) {
                            if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof Cell) {
                                chessBoard.board[i][j] = null;
                            } else if (chessBoard.board[i][j] != null) {
                                chessBoard.board[i][j].setCanSelectedPieceMoveHere(false);
                                chessBoard.board[i][j].setSelected(false);
                            }
                        }
                    }
                    chessBoard.board = chessBoard.board[x][y].availableCells(chessBoard.board);
                    for (int i = 1; i <= 11; i++) {
                        for (int j = 1; j <= 11; j++) {
                            if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof King &&
                                    chessBoard.board[i][j].getColor() != chessBoard.board[x][y].getColor()
                                    && chessBoard.board[i][j].isCanSelectedPieceMoveHere()) {
                                if ((chessBoard.board[i][j].getColor() == Color.BLACK && isBlackPlayerToMove)
                                        || (chessBoard.board[i][j].getColor() == Color.WHITE && !isBlackPlayerToMove)) {
                                    out = (King) chessBoard.board[i][j];
                                    break loop;
                                }
                            }
                        }
                    }
                }
            }
        }
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (chessBoard.board[x][y] != null && chessBoard.board[x][y] instanceof Cell) {
                    chessBoard.board[x][y] = null;
                } else if (chessBoard.board[x][y] != null) {
                    chessBoard.board[x][y].setCanSelectedPieceMoveHere(false);
                    chessBoard.board[x][y].setSelected(false);
                }
            }
        }
        return out;
    }

    public boolean isCheckmateOrStalemate() {
        boolean out = true;
        if (isBlackPlayerToMove) {
            loop1:
            for (int x = 1; x <= 11; x++) {
                for (int y = 1; y <= 11; y++) {
                    if (chessBoard.board[x][y] != null && chessBoard.board[x][y].getColor() == Color.BLACK && !(chessBoard.board[x][y] instanceof Cell)) {
                        for (int i = 1; i <= 11; i++) {
                            for (int j = 1; j <= 11; j++) {
                                if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof Cell) {
                                    chessBoard.board[i][j] = null;
                                } else if (chessBoard.board[i][j] != null) {
                                    chessBoard.board[i][j].setCanSelectedPieceMoveHere(false);
                                    chessBoard.board[i][j].setSelected(false);
                                }
                            }
                        }
                        changeBoard(x, y);
                        for (int i = 1; i <= 11; i++) {
                            for (int j = 1; j <= 11; j++) {
                                if (chessBoard.board[i][j] != null && chessBoard.graphicBoardChar[i][j] != 'j' && chessBoard.board[i][j].isCanSelectedPieceMoveHere()) {
                                    out = false;
                                    break loop1;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            loop2:
            for (int x = 1; x <= 11; x++) {
                for (int y = 1; y <= 11; y++) {
                    if (chessBoard.board[x][y] != null && chessBoard.board[x][y].getColor() == Color.WHITE && !(chessBoard.board[x][y] instanceof Cell)) {
                        for (int i = 1; i <= 11; i++) {
                            for (int j = 1; j <= 11; j++) {
                                if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof Cell) {
                                    chessBoard.board[i][j] = null;
                                } else if (chessBoard.board[i][j] != null) {
                                    chessBoard.board[i][j].setCanSelectedPieceMoveHere(false);
                                    chessBoard.board[i][j].setSelected(false);
                                }
                            }
                        }
                        changeBoard(x, y);
                        for (int i = 1; i <= 11; i++) {
                            for (int j = 1; j <= 11; j++) {
                                if (chessBoard.board[i][j] != null && chessBoard.graphicBoardChar[i][j] != 'j' && chessBoard.board[i][j].isCanSelectedPieceMoveHere()) {
                                    out = false;
                                    break loop2;
                                }
                            }
                        }
                    }
                }
            }
        }
        for (int i = 1; i <= 11; i++) {
            for (int j = 1; j <= 11; j++) {
                if (chessBoard.board[i][j] != null && chessBoard.board[i][j] instanceof Cell) {
                    chessBoard.board[i][j] = null;
                } else if (chessBoard.board[i][j] != null) {
                    chessBoard.board[i][j].setCanSelectedPieceMoveHere(false);
                    chessBoard.board[i][j].setSelected(false);
                }
            }
        }
        return out;
    }

    public void saveFile() {
        try {
            printWriter = new PrintWriter(file);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        if (isBlackPlayerToMove) {
            printWriter.println("B");
        } else {
            printWriter.println("W");
        }
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (chessBoard.board[x][y] != null) {
                    printWriter.print(x + " " + y + " ");
                    if (chessBoard.board[x][y].getColor() == Color.WHITE) {
                        printWriter.print("W ");
                        printWriter.println(chessBoard.board[x][y].getName());
                    } else if (chessBoard.board[x][y].getColor() == Color.BLACK) {
                        printWriter.print("B ");
                        printWriter.println(chessBoard.board[x][y].getName());
                    }
                }
            }
        }
        printWriter.flush();
        printWriter.close();
        try {
            printWriter2 = new PrintWriter(removed);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        for (int k = 0; k < chessBoard.removedPieces.size(); k++) {
            printWriter2.print(chessBoard.removedPieces.get(k).getX() + " " + chessBoard.removedPieces.get(k).getY() + " ");
            if (chessBoard.removedPieces.get(k).getColor() == Color.WHITE) {
                printWriter2.print("W ");
                printWriter2.println(chessBoard.removedPieces.get(k).getName());
            } else if (chessBoard.removedPieces.get(k).getColor() == Color.BLACK) {
                printWriter2.print("B ");
                printWriter2.println(chessBoard.removedPieces.get(k).getName());
            }
        }
        printWriter2.flush();
        printWriter2.close();
    }

    public void changeTurn() {
        isBlackPlayerToMove = !isBlackPlayerToMove;
        if (isBlackPlayerToMove) {
            application.setMessage("Black's Turn");
        } else {
            application.setMessage("White's Turn");
        }
    }

    public void moveFake(int x, int y) {
        loop:
        for (int i = 1; i <= 11; i++) {
            for (int j = 1; j <= 11; j++) {
                if (boardForCheck.board[i][j] != null && boardForCheck.board[i][j].isSelected()) {
                    if (boardForCheck.board[i][j] instanceof Rook) {
                        boardForCheck.board[x][y] = new Rook(x, y, boardForCheck.board[i][j].getColor(), boardForCheck.board[i][j].getName());
                    }
                    if (boardForCheck.board[i][j] instanceof Bishop) {
                        boardForCheck.board[x][y] = new Bishop(x, y, boardForCheck.board[i][j].getColor(), boardForCheck.board[i][j].getName());
                    }
                    if (boardForCheck.board[i][j] instanceof Queen) {
                        boardForCheck.board[x][y] = new Queen(x, y, boardForCheck.board[i][j].getColor(), boardForCheck.board[i][j].getName());
                    }
                    if (boardForCheck.board[i][j] instanceof King) {
                        boardForCheck.board[x][y] = new King(x, y, boardForCheck.board[i][j].getColor(), boardForCheck.board[i][j].getName());
                    }
                    if (boardForCheck.board[i][j] instanceof Knight) {
                        boardForCheck.board[x][y] = new Knight(x, y, boardForCheck.board[i][j].getColor(), boardForCheck.board[i][j].getName());
                    }
                    if (boardForCheck.board[i][j] instanceof Pawn) {
                        boardForCheck.board[x][y] = new Pawn(x, y, boardForCheck.board[i][j].getColor(), boardForCheck.board[i][j].getName());
                    }
                    boardForCheck.board[i][j] = null;
                    break loop;
                }
            }
        }
        for (int i = 1; i <= 11; i++) {
            for (int j = 1; j <= 11; j++) {
                if (boardForCheck.board[i][j] != null && boardForCheck.board[i][j] instanceof Cell) {
                    boardForCheck.board[i][j] = null;
                } else if (boardForCheck.board[i][j] != null) {
                    boardForCheck.board[i][j].setCanSelectedPieceMoveHere(false);
                    chessBoard.board[i][j].setSelected(false);
                }
            }
        }

    }

    public Board makeSameBoard(Board chessBoard) {
        Board putingBoard = new Board();
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                putingBoard.board[x][y] = null;
            }
        }
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (chessBoard.board[x][y] != null) {
                    if (chessBoard.board[x][y] instanceof Rook) {
                        putingBoard.board[x][y] = new Rook(x, y, chessBoard.board[x][y].getColor(), chessBoard.board[x][y].getName());
                        putingBoard.board[x][y].setSelected(chessBoard.board[x][y].isSelected());
                        putingBoard.board[x][y].setCanSelectedPieceMoveHere(chessBoard.board[x][y].isCanSelectedPieceMoveHere());
                    }
                    if (chessBoard.board[x][y] instanceof Bishop) {
                        putingBoard.board[x][y] = new Bishop(x, y, chessBoard.board[x][y].getColor(), chessBoard.board[x][y].getName());
                        putingBoard.board[x][y].setSelected(chessBoard.board[x][y].isSelected());
                        putingBoard.board[x][y].setCanSelectedPieceMoveHere(chessBoard.board[x][y].isCanSelectedPieceMoveHere());
                    }
                    if (chessBoard.board[x][y] instanceof Queen) {
                        putingBoard.board[x][y] = new Queen(x, y, chessBoard.board[x][y].getColor(), chessBoard.board[x][y].getName());
                        putingBoard.board[x][y].setSelected(chessBoard.board[x][y].isSelected());
                        putingBoard.board[x][y].setCanSelectedPieceMoveHere(chessBoard.board[x][y].isCanSelectedPieceMoveHere());
                    }
                    if (chessBoard.board[x][y] instanceof King) {
                        putingBoard.board[x][y] = new King(x, y, chessBoard.board[x][y].getColor(), chessBoard.board[x][y].getName());
                        putingBoard.board[x][y].setSelected(chessBoard.board[x][y].isSelected());
                        putingBoard.board[x][y].setCanSelectedPieceMoveHere(chessBoard.board[x][y].isCanSelectedPieceMoveHere());
                    }
                    if (chessBoard.board[x][y] instanceof Knight) {
                        putingBoard.board[x][y] = new Knight(x, y, chessBoard.board[x][y].getColor(), chessBoard.board[x][y].getName());
                        putingBoard.board[x][y].setSelected(chessBoard.board[x][y].isSelected());
                        putingBoard.board[x][y].setCanSelectedPieceMoveHere(chessBoard.board[x][y].isCanSelectedPieceMoveHere());
                    }
                    if (chessBoard.board[x][y] instanceof Pawn) {
                        putingBoard.board[x][y] = new Pawn(x, y, chessBoard.board[x][y].getColor(), chessBoard.board[x][y].getName());
                        putingBoard.board[x][y].setSelected(chessBoard.board[x][y].isSelected());
                        putingBoard.board[x][y].setCanSelectedPieceMoveHere(chessBoard.board[x][y].isCanSelectedPieceMoveHere());
                    }
                    if (chessBoard.board[x][y] instanceof Cell) {
                        putingBoard.board[x][y] = new Cell(x, y, null, null);
                        putingBoard.board[x][y].setCanSelectedPieceMoveHere(chessBoard.board[x][y].isCanSelectedPieceMoveHere());
                    }
                }
            }
        }
        return putingBoard;
    }

    public void putDefaultBoard() {
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (chessBoard.board[x][y] != null) {
                    chessBoard.board[x][y] = null;

                }
            }
            chessBoard.board[2][1] = new Pawn(2, 1, Color.WHITE, WHITE_PAWN);
            chessBoard.board[3][2] = new Pawn(3, 2, Color.WHITE, WHITE_PAWN);
            chessBoard.board[4][3] = new Pawn(4, 3, Color.WHITE, WHITE_PAWN);
            chessBoard.board[5][4] = new Pawn(5, 4, Color.WHITE, WHITE_PAWN);
            chessBoard.board[6][5] = new Pawn(6, 5, Color.WHITE, WHITE_PAWN);
            chessBoard.board[7][5] = new Pawn(7, 5, Color.WHITE, WHITE_PAWN);
            chessBoard.board[8][5] = new Pawn(8, 5, Color.WHITE, WHITE_PAWN);
            chessBoard.board[9][5] = new Pawn(9, 5, Color.WHITE, WHITE_PAWN);
            chessBoard.board[10][5] = new Pawn(10, 5, Color.WHITE, WHITE_PAWN);
            chessBoard.board[6][1] = new Bishop(6, 1, Color.WHITE, WHITE_BISHOP);
            chessBoard.board[6][2] = new Bishop(6, 2, Color.WHITE, WHITE_BISHOP);
            chessBoard.board[6][3] = new Bishop(6, 3, Color.WHITE, WHITE_BISHOP);
            chessBoard.board[3][1] = new Rook(3, 1, Color.WHITE, WHITE_ROCK);
            chessBoard.board[9][4] = new Rook(9, 4, Color.WHITE, WHITE_ROCK);
            chessBoard.board[4][1] = new Knight(4, 1, Color.WHITE, WHITE_KNIGHT);
            chessBoard.board[8][3] = new Knight(8, 3, Color.WHITE, WHITE_KNIGHT);
            chessBoard.board[5][1] = new Queen(5, 1, Color.WHITE, WHITE_QUEEN);
            chessBoard.board[7][2] = new King(7, 2, Color.WHITE, WHITE_KING);


            chessBoard.board[2][7] = new Pawn(2, 7, Color.BLACK, BLACK_PAWN);
            chessBoard.board[3][7] = new Pawn(3, 7, Color.BLACK, BLACK_PAWN);
            chessBoard.board[4][7] = new Pawn(4, 7, Color.BLACK, BLACK_PAWN);
            chessBoard.board[5][7] = new Pawn(5, 7, Color.BLACK, BLACK_PAWN);
            chessBoard.board[6][7] = new Pawn(6, 7, Color.BLACK, BLACK_PAWN);
            chessBoard.board[7][8] = new Pawn(7, 8, Color.BLACK, BLACK_PAWN);
            chessBoard.board[8][9] = new Pawn(8, 9, Color.BLACK, BLACK_PAWN);
            chessBoard.board[9][10] = new Pawn(9, 10, Color.BLACK, BLACK_PAWN);
            chessBoard.board[10][11] = new Pawn(10, 11, Color.BLACK, BLACK_PAWN);
            chessBoard.board[6][9] = new Bishop(6, 9, Color.BLACK, BLACK_BISHOP);
            chessBoard.board[6][10] = new Bishop(6, 10, Color.BLACK, BLACK_BISHOP);
            chessBoard.board[6][11] = new Bishop(6, 11, Color.BLACK, BLACK_BISHOP);
            chessBoard.board[3][8] = new Rook(3, 8, Color.BLACK, BLACK_ROCK);
            chessBoard.board[9][11] = new Rook(9, 11, Color.BLACK, BLACK_ROCK);
            chessBoard.board[4][9] = new Knight(4, 9, Color.BLACK, BLACK_KNIGHT);
            chessBoard.board[8][11] = new Knight(8, 11, Color.BLACK, BLACK_KNIGHT);
            chessBoard.board[5][10] = new Queen(5, 10, Color.BLACK, BLACK_QUEEN);
            chessBoard.board[7][11] = new King(7, 11, Color.BLACK, BLACK_KING);
        }
        try {
            printWriter = new PrintWriter(file);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        printWriter.print("W\n" +
                "2 1 W ♙\n" +
                "3 2 W ♙\n" +
                "4 3 W ♙\n" +
                "5 4 W ♙\n" +
                "6 5 W ♙\n" +
                "7 5 W ♙\n" +
                "8 5 W ♙\n" +
                "9 5 W ♙\n" +
                "10 5 W ♙\n" +
                "6 1 W ♗\n" +
                "6 2 W ♗\n" +
                "6 3 W ♗\n" +
                "3 1 W ♖\n" +
                "9 4 W ♖\n" +
                "4 1 W ♘\n" +
                "8 3 W ♘\n" +
                "5 1 W ♕\n" +
                "7 2 W ♔\n" +
                "2 7 B ♟\n" +
                "3 7 B ♟\n" +
                "4 7 B ♟\n" +
                "5 7 B ♟\n" +
                "6 7 B ♟\n" +
                "7 8 B ♟\n" +
                "8 9 B ♟\n" +
                "9 10 B ♟\n" +
                "10 11 B ♟\n" +
                "6 9 B ♝\n" +
                "6 10 B ♝\n" +
                "6 11 B ♝\n" +
                "3 8 B ♜\n" +
                "9 11 B ♜\n" +
                "4 9 B ♞\n" +
                "8 11 B ♞\n" +
                "5 10 B ♛\n" +
                "7 11 B ♚\n");
        printWriter.flush();
        printWriter.close();
        chessBoard.removedPieces.clear();
    }

    public void putGraphic() {
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (chessBoard.board[x][y] != null) {
                    application.setCellProperties(chessBoard.graphicBoardInt[x][y], chessBoard.graphicBoardChar[x][y], chessBoard.board[x][y].getName(), null, chessBoard.board[x][y].getColor());
                }
            }
        }
    }
}