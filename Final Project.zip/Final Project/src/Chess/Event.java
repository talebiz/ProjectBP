package Chess;

import ir.sharif.math.bp02_1.hex_chess.graphics.listeners.EventListener;

import java.io.File;

public class Event implements EventListener {
    Game game;

    public Event(Game game) {
        this.game = game;
    }

    @Override
    public void onClick(int row, char col) {
        for (int x = 1; x <= 11; x++) {
            for (int y = 1; y <= 11; y++) {
                if (game.chessBoard.graphicBoardChar[x][y] == col && game.chessBoard.graphicBoardInt[x][y] == row) {
                    game.changeBoard(x, y);
                }
            }
        }
    }

    @Override
    public void onLoad(File file) {
    }

    @Override
    public void onSave(File file) {

    }

    @Override
    public void onNewGame() {
        game = new Game(game.application);
        game.putDefaultBoard();
    }
}