package Chess.Pieces;

import java.awt.*;

public class Cell extends Piece {
    public Cell(int x, int y, Color color, String name) {
        super(x, y, color, name);
    }

    @Override
    public Piece[][] availableCells(Piece[][] board) {
        return board;
    }
}