package Chess.Pieces;

import java.awt.*;

public class Rook extends Piece {
    public Rook(int x, int y, Color color, String name) {
        super(x, y, color, name);
    }

    @Override
    public Piece[][] availableCells(Piece[][] board) {
        board[x][y].setSelected(true);
        for (int j = y + 1; (board[x][j] == null || board[x][j].getColor() != board[x][y].getColor())
                && j <= 11; j++) {
            if (board[x][j] != null) {
                board[x][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[x][j] = new Cell(x, j, null, null);
                board[x][j].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int j = y - 1; (board[x][j] == null || board[x][j].getColor() != board[x][y].getColor())
                && j > 0; j--) {
            if (board[x][j] != null) {
                board[x][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[x][j] = new Cell(x, j, null, null);
                board[x][j].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int i = x + 1; (board[i][y] == null || board[i][y].getColor() != board[x][y].getColor())
                && i <= 11; i++) {
            if (board[i][y] != null) {
                board[i][y].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][y] = new Cell(i, y, null, null);
                board[i][y].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int i = x - 1; (board[i][y] == null || board[i][y].getColor() != board[x][y].getColor())
                && i > 0; i--) {
            if (board[i][y] != null) {
                board[i][y].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][y] = new Cell(i, y, null, null);
                board[i][y].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int i = x + 1, j = y + 1; (board[i][j] == null || board[i][j].getColor() != board[x][y].getColor())
                && i <= 11 && j <= 11; i++, j++) {
            if (board[i][j] != null) {
                board[i][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][j] = new Cell(i, j, null, null);
                board[i][j].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int i = x - 1, j = y - 1; (board[i][j] == null || board[i][j].getColor() != board[x][y].getColor())
                && i > 0 && j > 0; i--, j--) {
            if (board[i][j] != null) {
                board[i][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][j] = new Cell(i, j, null, null);
                board[i][j].setCanSelectedPieceMoveHere(true);
            }
        }
        return board;
    }
}