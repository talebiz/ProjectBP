package Chess.Pieces;

import java.awt.*;

public class Pawn extends Piece {
    public Pawn(int x, int y, Color color, String name) {
        super(x, y, color, name);
    }

    @Override
    public Piece[][] availableCells(Piece[][] board) {
        board[x][y].setSelected(true);
        if (color == Color.BLACK) {
            if ((y == 7 && x <= 6) || (x + 1 == y && x > 6) && board[x][y - 1] == null) {
                try {
                    if (board[x][y - 2] == null && board[x][y - 1] == null) {
                        if (board[x][y - 2] != null) {
                            board[x][y - 2].setCanSelectedPieceMoveHere(true);
                        } else {
                            board[x][y - 2] = new Cell(x, y - 2, null, null);
                            board[x][y - 2].setCanSelectedPieceMoveHere(true);
                        }
                    }
                } catch (Exception e) {
                }
            }
            try {
                if (board[x][y - 1] == null) {
                    if (board[x][y - 1] != null) {
                        board[x][y - 1].setCanSelectedPieceMoveHere(true);
                    } else {
                        board[x][y - 1] = new Cell(x, y - 1, null, null);
                        board[x][y - 1].setCanSelectedPieceMoveHere(true);
                    }
                }
            } catch (Exception e) {
            }

            try {
                if (board[x + 1][y] != null && board[x + 1][y].getColor() != board[x][y].getColor()) {
                    board[x + 1][y].setCanSelectedPieceMoveHere(true);
                }
            } catch (Exception e) {
            }
            try {
                if (board[x - 1][y - 1] != null && board[x - 1][y - 1].getColor() != board[x][y].getColor()) {
                    board[x - 1][y - 1].setCanSelectedPieceMoveHere(true);
                }
            } catch (Exception e) {
            }
        } else {
            if ((y == 5 && x >= 6) || (y + 1 == x && x < 6) && board[x][y + 1] == null) {
                try {
                    if (board[x][y + 2] == null && board[x][y + 1] == null) {
                        if (board[x][y + 2] != null) {
                            board[x][y + 2].setCanSelectedPieceMoveHere(true);
                        } else {
                            board[x][y + 2] = new Cell(x, y + 2, null, null);
                            board[x][y + 2].setCanSelectedPieceMoveHere(true);
                        }
                    }
                } catch (Exception e) {
                }
            }
            try {
                if (board[x][y + 1] == null) {
                    if (board[x][y + 1] != null) {
                        board[x][y + 1].setCanSelectedPieceMoveHere(true);
                    } else {
                        board[x][y + 1] = new Cell(x, y + 1, null, null);
                        board[x][y + 1].setCanSelectedPieceMoveHere(true);
                    }
                }
            } catch (Exception e) {
            }
            try {
                if (board[x - 1][y] != null && board[x - 1][y].getColor() != board[x][y].getColor()) {
                    board[x - 1][y].setCanSelectedPieceMoveHere(true);
                }
            } catch (Exception e) {
            }
            try {


                if (board[x + 1][y + 1] != null && board[x + 1][y + 1].getColor() != board[x][y].getColor()) {
                    board[x + 1][y + 1].setCanSelectedPieceMoveHere(true);
                }
            } catch (Exception e) {
            }
        }
        return board;
    }
}