package Chess.Pieces;
import java.awt.*;
abstract public class Piece {
    protected int x;
    protected int y;
    protected Color color;
    protected String name;
    protected boolean isSelected;
    protected boolean canSelectedPieceMoveHere;
    public Piece(int x, int y, Color color, String name) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.name = name;
    }
    abstract public Piece[][] availableCells(Piece[][] board);
    public int getX() {
        return x;
    }
    public void setX(int x) {
        this.x = x;
    }
    public int getY() {
        return y;
    }
    public void setY(int y) {
        this.y = y;
    }
    public Color getColor() {
        return color;
    }
    public void setColor(Color color) {
        this.color = color;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public boolean isSelected() {
        return isSelected;
    }
    public void setSelected(boolean selected) {
        isSelected = selected;
    }
    public boolean isCanSelectedPieceMoveHere() {
        return canSelectedPieceMoveHere;
    }
    public void setCanSelectedPieceMoveHere(boolean canSelectedPieceMoveHere) {
        this.canSelectedPieceMoveHere = canSelectedPieceMoveHere;
    }
}