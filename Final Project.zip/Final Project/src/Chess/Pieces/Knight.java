package Chess.Pieces;

import java.awt.*;

public class Knight extends Piece {
    public Knight(int x, int y, Color color, String name) {
        super(x, y, color, name);
    }

    @Override
    public Piece[][] availableCells(Piece[][] board) {
        board[x][y].setSelected(true);
        try {
            if (board[x + 1][y + 3] == null || board[x + 1][y + 3].getColor() != board[x][y].getColor()) {
                if (board[x + 1][y + 3] != null) {
                    board[x + 1][y + 3].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 1][y + 3] = new Cell(x + 1, y + 3, null, null);
                    board[x + 1][y + 3].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 1][y + 2] == null || board[x - 1][y + 2].getColor() != board[x][y].getColor()) {
                if (board[x - 1][y + 2] != null) {
                    board[x - 1][y + 2].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 1][y + 2] = new Cell(x - 1, y + 2, null, null);
                    board[x - 1][y + 2].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 1][y - 3] == null || board[x - 1][y - 3].getColor() != board[x][y].getColor()) {
                if (board[x - 1][y - 3] != null) {
                    board[x - 1][y - 3].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 1][y - 3] = new Cell(x - 1, y - 3, null, null);
                    board[x - 1][y - 3].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x + 1][y - 2] == null || board[x + 1][y - 2].getColor() != board[x][y].getColor()) {
                if (board[x + 1][y - 2] != null) {
                    board[x + 1][y - 2].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 1][y - 2] = new Cell(x + 1, y - 2, null, null);
                    board[x + 1][y - 2].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x + 2][y + 3] == null || board[x + 2][y + 3].getColor() != board[x][y].getColor()) {
                if (board[x + 2][y + 3] != null) {
                    board[x + 2][y + 3].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 2][y + 3] = new Cell(x + 2, y + 3, null, null);
                    board[x + 2][y + 3].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x + 3][y + 2] == null || board[x + 3][y + 2].getColor() != board[x][y].getColor()) {
                if (board[x + 3][y + 2] != null) {
                    board[x + 3][y + 2].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 3][y + 2] = new Cell(x + 3, y + 2, null, null);
                    board[x + 3][y + 2].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x + 2][y - 1] == null || board[x + 2][y - 1].getColor() != board[x][y].getColor()) {
                if (board[x + 2][y - 1] != null) {
                    board[x + 2][y - 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 2][y - 1] = new Cell(x + 2, y - 1, null, null);
                    board[x + 2][y - 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x + 3][y + 1] == null || board[x + 3][y + 1].getColor() != board[x][y].getColor()) {
                if (board[x + 3][y + 1] != null) {
                    board[x + 3][y + 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 3][y + 1] = new Cell(x + 3, y + 1, null, null);
                    board[x + 3][y + 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 2][y - 3] == null || board[x - 2][y - 3].getColor() != board[x][y].getColor()) {
                if (board[x - 2][y - 3] != null) {
                    board[x - 2][y - 3].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 2][y - 3] = new Cell(x - 2, y - 3, null, null);
                    board[x - 2][y - 3].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 3][y - 2] == null || board[x - 3][y - 2].getColor() != board[x][y].getColor()) {
                if (board[x - 3][y - 2] != null) {
                    board[x - 3][y - 2].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 3][y - 2] = new Cell(x - 3, y - 2, null, null);
                    board[x - 3][y - 2].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 2][y + 1] == null || board[x - 2][y + 1].getColor() != board[x][y].getColor()) {
                if (board[x - 2][y + 1] != null) {
                    board[x - 2][y + 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 2][y + 1] = new Cell(x - 2, y + 1, null, null);
                    board[x - 2][y + 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 3][y - 1] == null || board[x - 3][y - 1].getColor() != board[x][y].getColor()) {
                if (board[x - 3][y - 1] != null) {
                    board[x - 3][y - 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 3][y - 1] = new Cell(x - 3, y - 1, null, null);
                    board[x - 3][y - 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }
        return board;
    }
}