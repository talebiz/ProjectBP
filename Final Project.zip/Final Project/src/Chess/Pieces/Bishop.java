package Chess.Pieces;

import java.awt.*;

public class Bishop extends Piece {
    public Bishop(int x, int y, Color color, String name) {
        super(x, y, color, name);
    }

    @Override
    public Piece[][] availableCells(Piece[][] board) {
        board[x][y].setSelected(true);
        for (int i = x + 2, j = y + 1; i <= 11 && j <= 11 && (board[i][j] == null || board[i][j].getColor() != board[x][y].getColor())
                ; i += 2, j++) {
            if (board[i][j] != null) {
                board[i][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][j] = new Cell(i, j, null, null);
                board[i][j].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int i = x - 2, j = y - 1; i > 0 && j > 0 && (board[i][j] == null || board[i][j].getColor() != board[x][y].getColor())
                ; i -= 2, j--) {
            if (board[i][j] != null) {
                board[i][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][j] = new Cell(i, j, null, null);
                board[i][j].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int i = x + 1, j = y + 2; i <= 11 && j <= 11 && (board[i][j] == null || board[i][j].getColor() != board[x][y].getColor())
                ; i++, j += 2) {
            if (board[i][j] != null) {
                board[i][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][j] = new Cell(i, j, null, null);
                board[i][j].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int i = x - 1, j = y - 2; i > 0 && j > 0 && (board[i][j] == null || board[i][j].getColor() != board[x][y].getColor())
                ; i--, j -= 2) {
            if (board[i][j] != null) {
                board[i][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][j] = new Cell(i, j, null, null);
                board[i][j].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int i = x + 1, j = y - 1; i <= 11 && j > 0 && (board[i][j] == null || board[i][j].getColor() != board[x][y].getColor())
                ; i++, j--) {
            if (board[i][j] != null) {
                board[i][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][j] = new Cell(i, j, null, null);
                board[i][j].setCanSelectedPieceMoveHere(true);
            }
        }
        for (int i = x - 1, j = y + 1; i > 0 && j <= 11 && (board[i][j] == null || board[i][j].getColor() != board[x][y].getColor())
                ; i--, j++) {
            if (board[i][j] != null) {
                board[i][j].setCanSelectedPieceMoveHere(true);
                break;
            } else {
                board[i][j] = new Cell(i, j, null, null);
                board[i][j].setCanSelectedPieceMoveHere(true);
            }
        }
        return board;
    }
}