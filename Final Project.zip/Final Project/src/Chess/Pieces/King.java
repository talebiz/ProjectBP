package Chess.Pieces;

import java.awt.*;

public class King extends Piece {
    public King(int x, int y, Color color, String name) {
        super(x, y, color, name);
    }

    @Override
    public Piece[][] availableCells(Piece[][] board) {
        board[x][y].setSelected(true);
        try {
            if (board[x + 2][y + 1] == null || board[x + 2][y + 1].getColor() != board[x][y].getColor()) {
                if (board[x + 2][y + 1] != null) {
                    board[x + 2][y + 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 2][y + 1] = new Cell(x + 2, y + 1, null, null);
                    board[x + 2][y + 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 2][y - 1] == null || board[x - 2][y - 1].getColor() != board[x][y].getColor()) {
                if (board[x - 2][y - 1] != null) {
                    board[x - 2][y - 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 2][y - 1] = new Cell(x - 2, y - 1, null, null);
                    board[x - 2][y - 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x + 1][y + 2] == null || board[x + 1][y + 2].getColor() != board[x][y].getColor()) {
                if (board[x + 1][y + 2] != null) {
                    board[x + 1][y + 2].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 1][y + 2] = new Cell(x + 1, y + 2, null, null);
                    board[x + 1][y + 2].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 1][y - 2] == null || board[x - 1][y - 2].getColor() != board[x][y].getColor()) {
                if (board[x - 1][y - 2] != null) {
                    board[x - 1][y - 2].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 1][y - 2] = new Cell(x - 1, y - 2, null, null);
                    board[x - 1][y - 2].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x + 1][y - 1] == null || board[x + 1][y - 1].getColor() != board[x][y].getColor()) {
                if (board[x + 1][y - 1] != null) {
                    board[x + 1][y - 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 1][y - 1] = new Cell(x + 1, y - 1, null, null);
                    board[x + 1][y - 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 1][y + 1] == null || board[x - 1][y + 1].getColor() != board[x][y].getColor()) {
                if (board[x - 1][y + 1] != null) {
                    board[x - 1][y + 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 1][y + 1] = new Cell(x - 1, y + 1, null, null);
                    board[x - 1][y + 1].setCanSelectedPieceMoveHere(true);
                }

            }
        } catch (Exception e) {
        }

        try {
            if (board[x][y + 1] == null || board[x][y + 1].getColor() != board[x][y].getColor()) {
                if (board[x][y + 1] != null) {
                    board[x][y + 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x][y + 1] = new Cell(x, y + 1, null, null);
                    board[x][y + 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x][y - 1] == null || board[x][y - 1].getColor() != board[x][y].getColor()) {
                if (board[x][y - 1] != null) {
                    board[x][y - 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x][y - 1] = new Cell(x, y - 1, null, null);
                    board[x][y - 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x + 1][y] == null || board[x + 1][y].getColor() != board[x][y].getColor()) {
                if (board[x + 1][y] != null) {
                    board[x + 1][y].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 1][y] = new Cell(x + 1, y, null, null);
                    board[x + 1][y].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 1][y] == null || board[x - 1][y].getColor() != board[x][y].getColor()) {
                if (board[x - 1][y] != null) {
                    board[x - 1][y].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 1][y] = new Cell(x - 1, y, null, null);
                    board[x - 1][y].setCanSelectedPieceMoveHere(true);
                }

            }
        } catch (Exception e) {
        }

        try {
            if (board[x + 1][y + 1] == null || board[x + 1][y + 1].getColor() != board[x][y].getColor()) {
                if (board[x + 1][y + 1] != null) {
                    board[x + 1][y + 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x + 1][y + 1] = new Cell(x + 1, y + 1, null, null);
                    board[x + 1][y + 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }

        try {
            if (board[x - 1][y - 1] == null || board[x - 1][y - 1].getColor() != board[x][y].getColor()) {
                if (board[x - 1][y - 1] != null) {
                    board[x - 1][y - 1].setCanSelectedPieceMoveHere(true);
                } else {
                    board[x - 1][y - 1] = new Cell(x - 1, y - 1, null, null);
                    board[x - 1][y - 1].setCanSelectedPieceMoveHere(true);
                }
            }
        } catch (Exception e) {
        }


        return board;
    }
}
